import tkinter as tk
from tkinter import ttk
import random
import math

class MathQuizApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🎓 Math Quiz App")
        self.root.geometry("520x420")
        self.root.resizable(False, False)

        # Style and colors
        style = ttk.Style()
        style.theme_use('clam')

        self.bg_color = "#f0f8ff"  # AliceBlue
        self.frame_bg = "#e6f0fa"
        self.accent_color = "#2a9df4"  # Bright blue
        self.correct_color = "#228B22"  # Forest green
        self.wrong_color = "#b22222"  # Firebrick red

        self.root.config(bg=self.bg_color)

        # Use a font that supports math symbols
        font_family = 'Segoe UI Symbol'

        style.configure('TLabel', font=(font_family, 12), background=self.frame_bg)
        style.configure('Header.TLabel', font=(font_family, 18, 'bold'), background=self.frame_bg, foreground=self.accent_color)
        style.configure('TButton', font=(font_family, 12), padding=6)
        style.configure('TEntry', font=(font_family, 12))

        # Game variables
        self.level = 1
        self.score = 0
        self.correct_answer = None
        self.current_question = ""
        self.user_grade = None

        # Frames
        self.menu_frame = tk.Frame(self.root, bg=self.frame_bg, padx=20, pady=20)
        self.quiz_frame = tk.Frame(self.root, bg=self.frame_bg, padx=20, pady=20)

        self.setup_menu()
        self.setup_quiz_ui()

        self.menu_frame.pack(fill='both', expand=True)

    def setup_menu(self):
        title = tk.Label(self.menu_frame, text="🎓 Welcome to Math Quiz!", font=('Segoe UI Symbol', 20, 'bold'), fg=self.accent_color, bg=self.frame_bg)
        title.pack(pady=(0, 15))

        prompt = tk.Label(self.menu_frame, text="Select your grade:", font=('Segoe UI Symbol', 14), bg=self.frame_bg)
        prompt.pack(pady=5)

        self.grade_var = tk.StringVar()
        grade_combo = ttk.Combobox(self.menu_frame, textvariable=self.grade_var, state="readonly", width=12)
        grade_combo['values'] = [str(i) for i in range(1, 13)]
        grade_combo.current(0)
        grade_combo.pack(pady=5)

        start_button = ttk.Button(self.menu_frame, text="Start Quiz", command=self.start_quiz)
        start_button.pack(pady=20)

    def setup_quiz_ui(self):
        self.header_label = tk.Label(self.quiz_frame, text="🧮 Math Quiz", font=('Segoe UI Symbol', 20, 'bold'), fg=self.accent_color, bg=self.frame_bg)
        self.header_label.grid(column=0, row=0, columnspan=3)

        self.score_label = tk.Label(self.quiz_frame, text="Score: 0", font=('Segoe UI Symbol', 14), bg=self.frame_bg)
        self.score_label.grid(column=0, row=1, columnspan=3, pady=5)

        self.question_label = tk.Label(self.quiz_frame, text="Question:", wraplength=480, font=('Segoe UI Symbol', 14), bg=self.frame_bg)
        self.question_label.grid(column=0, row=2, columnspan=3, pady=15)

        self.answer_var = tk.StringVar()
        self.answer_entry = ttk.Entry(self.quiz_frame, width=30, textvariable=self.answer_var)
        self.answer_entry.grid(column=0, row=3, padx=(0, 10))
        self.answer_entry.bind('<Return>', lambda e: self.check_answer())

        self.submit_button = ttk.Button(self.quiz_frame, text="Submit", command=self.check_answer)
        self.submit_button.grid(column=1, row=3)

        # Back to Menu button added here
        self.back_button = ttk.Button(self.quiz_frame, text="Back to Menu", command=self.back_to_menu)
        self.back_button.grid(column=2, row=3, padx=(10,0))

        self.feedback_label = tk.Label(self.quiz_frame, text="", font=('Segoe UI Symbol', 12), bg=self.frame_bg)
        self.feedback_label.grid(column=0, row=4, columnspan=3, pady=15)

        self.next_button = ttk.Button(self.quiz_frame, text="Next Question", command=self.new_question, state='disabled')
        self.next_button.grid(column=0, row=5, columnspan=3)

        for child in self.quiz_frame.winfo_children():
            child.grid_configure(padx=7, pady=7)

    def start_quiz(self):
        grade = int(self.grade_var.get())
        self.user_grade = grade

        if grade <= 3:
            self.level = 1
        elif grade <= 6:
            self.level = 3
        elif grade <= 9:
            self.level = 5
        else:
            self.level = 7

        self.score = 0
        self.score_label.config(text="Score: 0")

        self.menu_frame.pack_forget()
        self.quiz_frame.pack(fill='both', expand=True)
        self.new_question()

    def back_to_menu(self):
        # Reset everything and show menu
        self.quiz_frame.pack_forget()
        self.menu_frame.pack(fill='both', expand=True)
        self.level = 1
        self.score = 0
        self.score_label.config(text="Score: 0")
        self.feedback_label.config(text="")
        self.answer_var.set('')
        self.submit_button.config(state='normal')
        self.next_button.config(state='disabled')

    def new_question(self):
        self.feedback_label.config(text="", fg="black")
        self.answer_entry.config(state='normal')
        self.submit_button.config(state='normal')
        self.next_button.config(state='disabled')

        self.answer_var.set('')
        self.answer_entry.focus()

        if self.user_grade <= 6:
            self.current_question, self.correct_answer = self.arithmetic_question()
        elif self.user_grade <= 9:
            self.current_question, self.correct_answer = self.algebra_question()
        else:
            self.current_question, self.correct_answer = self.advanced_question()

        self.question_label.config(text=self.current_question)

    # Grade 1-6: Basic arithmetic with math symbols
    def arithmetic_question(self):
        operations = ['+', '-', '×', '÷']
        op = random.choice(operations)
        max_val = 10 + (self.level * 5)

        if op == '+':
            a = random.randint(1, max_val)
            b = random.randint(1, max_val)
            answer = a + b
            question = f"What is {a} + {b}?"

        elif op == '-':
            a = random.randint(1, max_val)
            b = random.randint(1, a)
            answer = a - b
            question = f"What is {a} − {b}?"

        elif op == '×':
            a = random.randint(1, self.level + 5)
            b = random.randint(1, self.level + 5)
            answer = a * b
            question = f"What is {a} × {b}?"

        else:  # division ÷
            b = random.randint(1, self.level + 5)
            answer = random.randint(1, self.level + 5)
            a = b * answer
            question = f"What is {a} ÷ {b}?"

        return question, answer

    # Grade 7-9: Algebra (linear equations)
    def algebra_question(self):
        a = random.randint(1, 10)
        x = random.randint(1, 20)
        b = random.randint(-10, 10)
        c = a * x + b
        question = f"Solve for x: {a}x + {b} = {c}"
        answer = x
        return question, answer

    # Grade 10-12: Advanced (quadratic vertex, derivative, trig with math symbols)
    def advanced_question(self):
        q_type = random.choice(['quadratic_vertex', 'derivative_basic', 'trig_value'])

        if q_type == 'quadratic_vertex':
            a = random.choice([1, 2, 3])
            b = random.randint(-10, 10)
            c = random.randint(-10, 10)
            question = f"Find the vertex of the parabola f(x) = {a}x² + {b}x + {c}.\n" \
                       f"Enter as x,y rounded to 2 decimals (e.g., 1.23,-4.56)."
            vx = -b / (2 * a)
            vy = a * vx ** 2 + b * vx + c
            answer = (round(vx, 2), round(vy, 2))
            return question, answer

        elif q_type == 'derivative_basic':
            a = random.randint(1, 5)
            n = random.randint(2, 5)
            question = f"Find the derivative of f(x) = {a}x^{n}. Enter as coef,power (e.g., 12,2)."
            coef = a * n
            power = n - 1
            answer = (coef, power)
            return question, answer

        else:  # trig_value
            func = random.choice(['sin', 'cos', 'tan'])
            angle_deg = random.choice([0, 30, 45, 60, 90])
            question = f"What is {func}({angle_deg}°)? Enter answer rounded to 2 decimals."
            angle_rad = math.radians(angle_deg)
            val = {
                'sin': math.sin(angle_rad),
                'cos': math.cos(angle_rad),
                'tan': math.tan(angle_rad) if angle_deg not in [90, 270] else float('inf')
            }[func]
            if math.isinf(val):
                answer = "undefined"
            else:
                answer = round(val, 2)
            return question, answer

    def check_answer(self):
        user_input = self.answer_var.get().strip()

        if self.user_grade <= 6:
            try:
                user_answer = float(user_input)
                correct = abs(user_answer - self.correct_answer) < 0.01
            except ValueError:
                self.feedback_label.config(text="Please enter a valid number.", fg=self.wrong_color)
                return

        elif self.user_grade <= 9:
            try:
                user_answer = float(user_input)
                correct = abs(user_answer - self.correct_answer) < 0.01
            except ValueError:
                self.feedback_label.config(text="Please enter a valid number.", fg=self.wrong_color)
                return

        else:
            if isinstance(self.correct_answer, tuple):
                if len(self.correct_answer) == 2:
                    if ',' not in user_input:
                        self.feedback_label.config(
                            text="Enter two numbers separated by a comma.", fg=self.wrong_color)
                        return
                    parts = user_input.split(',')
                    if len(parts) != 2:
                        self.feedback_label.config(
                            text="Enter exactly two numbers separated by a comma.", fg=self.wrong_color)
                        return
                    try:
                        num1 = float(parts[0])
                        num2 = float(parts[1])
                    except ValueError:
                        self.feedback_label.config(
                            text="Please enter valid numbers.", fg=self.wrong_color)
                        return
                    diff1 = abs(num1 - self.correct_answer[0])
                    diff2 = abs(num2 - self.correct_answer[1])
                    correct = (diff1 < 0.05) and (diff2 < 0.05)
                else:
                    correct = False
            else:
                if self.correct_answer == "undefined":
                    correct = user_input.lower() == "undefined"
                else:
                    try:
                        val = float(user_input)
                        correct = abs(val - self.correct_answer) < 0.05
                    except ValueError:
                        correct = False

        if correct:
            self.score += 1
            self.level += 1
            self.feedback_label.config(text="Correct! 🎉", fg=self.correct_color)
        else:
            if isinstance(self.correct_answer, tuple):
                correct_str = ', '.join(map(str, self.correct_answer))
            else:
                correct_str = str(self.correct_answer)
            self.feedback_label.config(
                text=f"Incorrect! Correct answer: {correct_str}", fg=self.wrong_color
            )

        self.score_label.config(text=f"Score: {self.score}")
        self.submit_button.config(state='disabled')
        self.next_button.config(state='enabled')


if __name__ == "__main__":
    root = tk.Tk()
    app = MathQuizApp(root)
    root.mainloop()
